/* Public domain. */

#ifndef LOCK_H
#define LOCK_H

extern int lock_ex(int);
extern int lock_un(int);
extern int lock_exnb(int);

#endif
