#include <sys/wait.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <signal.h>
#include "startup.h"

static pid_t child_pid = -1;

int execute_cmd(char **cmd) {

    int status = 1;
    pid_t pid;

    child_pid = fork();
    if (child_pid < 0) {
        printf("ERROR: %s %s failed to fork.\n", cmd[0], cmd[1]);
        return -1;

    } else if (child_pid == 0) {
        /* child */
        if (execvp(cmd[0], &cmd[0]) == -1) {
            printf("ERROR: %s %s execvp failed errno: %d.\n", cmd[0], cmd[1], errno);
            exit(-1);
        }
    } else {
        /* parent */
        int signum;
        sigset_t all_signals;
        sigfillset(&all_signals);
        sigprocmask(SIG_BLOCK, &all_signals, NULL);

        for (;;) {
            sigwait(&all_signals, &signum);
            if (signum == SIGCHLD) {
                while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
                    if (pid == child_pid) {
                        if (status == 0)
                            return 0;
                        else if (WIFEXITED(status))
                            printf("%s %s exited: %d\n", cmd[0], cmd[1], WEXITSTATUS(status));
                        else
                            printf("ERROR: %s %s abnormal exit: %d\n", cmd[0], cmd[1], status);
                        return status;
                    }
                }
                printf("ERROR: %s %s failed to get exit code\n", cmd[0], cmd[1]);
                return -2;
            } else {
                kill(child_pid, signum);
            }
        }
    }

    return -3;
}

static int run_startup_script(const char *filename) {
    char *cmd[3];
    char *ext;

    ext = strrchr(filename, '.');
    if (!ext)
        return 0;

    if (strcmp(ext, ".sh") == 0) {

        cmd[0] = "sh";
        cmd[1] = (char *)filename;
        cmd[2] = NULL;
        return execute_cmd(cmd);

    } else if (strcmp(ext, ".py") == 0) {

        cmd[0] = "python";
        cmd[1] = (char *)filename;
        cmd[2] = NULL;
        return execute_cmd(cmd);
    }

    return 0;
}

int run_startup_scripts(char *dir) {
    int i;
    int n;
    char *filepath;
    struct dirent **dir_list;

    if (0 != access(dir, R_OK)) {
        if (ENOENT == errno) {
            printf("INFO: %s does not exist, no startup scripts will be exectued.\n", dir);
            return 0;
        } else if (ENOTDIR == errno) {
            printf("ERROR: %s is not a directory.\n", dir);
            return errno;
        } else if (EACCES == errno) {
            printf("ERROR: %s access error could not read.\n", dir);
            return errno;
        }
        printf("ERROR access(%s) errno:%d :%s\n",
                dir,
                errno,
                strerror(errno));

        return errno;
    }

    if ((n = scandir(dir, &dir_list, NULL, alphasort)) < 0) {
        printf("ERROR: %s scandir failed and returned  %d.\n", dir, n);
        return n;
    }

    char *strcpyftm;
    if (dir[strlen(dir)-1] != '/')
        strcpyftm = "%s/%s";
    else
        strcpyftm = "%s%s";

    for (i = 0; i < n; i++) {
        if (dir_list[i]->d_type != DT_REG)
            continue;

        filepath = (char*)malloc(strlen(dir) + strlen(dir_list[i]->d_name) + 2);
        sprintf(filepath, strcpyftm, dir, dir_list[i]->d_name);

        run_startup_script(filepath);

        free(filepath);
        free(dir_list[i]);
    }

    free(dir_list);
    return 0;
}

/*
int main() {
    return run_startup_scripts("./test");
}
*/
