/* Public domain. */

#include <sys/types.h>
#include <time.h>
#include <sys/time.h>
#include <sys/select.h> /* SVR4 silliness */

void foo()
{
  ;
}
