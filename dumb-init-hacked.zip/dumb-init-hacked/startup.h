#ifndef __STARTUP_H
#define __STARTUP_H

int run_startup_scripts(char *dir);

#endif
