import argparse
from time import sleep
from multiprocessing import Event
from datetime import datetime
import os
import sys
import signal

_termniate = Event()

def signal_handler(signum, frame):
    print 'signum: ', signum
    _termniate.set()


if __name__ == "__main__":

    signal.signal(signal.SIGTERM, signal_handler)

    parser = argparse.ArgumentParser(description='Loads and dumps cloudburst configs from the supplied redis db.',
                                     add_help=False)

    parser.add_argument('--print-sleep',
                        type=float,
                        default=2.33)

    parser.add_argument('--exit-sleep',
                        type=float,
                        default=1.25)

    parser.add_argument('--exit-status',
                        type=int,
                        default=0)

    args = parser.parse_args()

    print 'pid: {0}'.format(os.getpid())

    while True:
        try:
            print '{0}'.format(datetime.now())
            sleep(args.print_sleep)
            if _termniate.is_set():
                break
        except KeyboardInterrupt:
            break

    print ''
    print 'exiting test {0}'.format(datetime.now())
    sleep(args.exit_sleep)
    print 'sys.exit({0})'.format(args.exit_status)
    sys.exit(args.exit_status)
